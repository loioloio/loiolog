# -*- coding: utf-8 -*-
"""
LoioLog — Advanced Kodi log manager.

Author: loioloio
License: GPL-2.0-or-later
"""
import sys
import os
import re
import json
import time
import base64
import urllib.parse
from collections import Counter

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs


_ADDON = xbmcaddon.Addon()
_ADDON_NAME = _ADDON.getAddonInfo("name")


_SENSITIVE_PATTERNS = [
    re.compile(r'(access_token=)[^&\s]+'),
    re.compile(r'(bearer=)[^&\s]+'),
    re.compile(r'(hdnts=)[^&\s]+'),
    re.compile(r'(token=)[^&\s]+'),
    re.compile(r'(api_key=)[^&\s]+'),
    re.compile(r'(password=)[^&\s]+'),
    re.compile(r'(Authorization:\s*Bearer\s+)\S+', re.IGNORECASE),
]

_SEVERITY_ERROR_TERMS = (' error ', 'exception', 'traceback')
_SEVERITY_WARNING_TERMS = ('warning',)
_SEVERITY_DEBUG_TERMS = (' debug ',)

_KODI_LOG_TAGS = (
    'info <general>:',
    'error <general>:',
    'warning <general>:',
    'debug <general>:',
    'notice <general>:',
)

_ADDON_NAME_RE = re.compile(r'\[([A-Za-z0-9_.\-]+)\]')


def _T(string_id):
    """Return the localized string for the given ID."""
    return _ADDON.getLocalizedString(string_id)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _u(**kwargs):
    """Build a plugin URL from keyword arguments."""
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def _is_sanitize_enabled():
    return _ADDON.getSetting("sanitize_enabled") == "true"


def _is_reverse_enabled():
    return _ADDON.getSetting("reverse_log") == "true"


def _sanitize_log_line(line):
    """Mask sensitive tokens in a log line if sanitization is enabled."""
    if not _is_sanitize_enabled():
        return line
    for pattern in _SENSITIVE_PATTERNS:
        line = pattern.sub(lambda m: m.group(1) + '***', line)
    return line


def _get_log_path():
    return xbmcvfs.translatePath("special://logpath/kodi.log")


def _get_old_log_path():
    return xbmcvfs.translatePath("special://logpath/kodi.old.log")


def _copy_to_clipboard(text):
    """Copy text to the system clipboard. Returns True on success."""
    import subprocess
    try:
        if sys.platform == 'win32':
            subprocess.Popen(['clip'], stdin=subprocess.PIPE).communicate(
                text.encode('utf-8'))
        elif sys.platform == 'darwin':
            subprocess.Popen(['pbcopy'], stdin=subprocess.PIPE).communicate(
                text.encode('utf-8'))
        else:
            try:
                subprocess.Popen(['xclip', '-selection', 'clipboard'],
                                 stdin=subprocess.PIPE).communicate(
                    text.encode('utf-8'))
            except FileNotFoundError:
                subprocess.Popen(['xsel', '--clipboard', '--input'],
                                 stdin=subprocess.PIPE).communicate(
                    text.encode('utf-8'))
        return True
    except Exception:
        return False


def _read_file_lines(path):
    """Read all lines from a file. Returns [] if missing or unreadable."""
    if not os.path.exists(path):
        return []
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as fh:
            return fh.readlines()
    except OSError:
        return []


def _read_log_lines():
    return _read_file_lines(_get_log_path())


def _get_filter_term():
    """Return the current filter term from settings, lowercased."""
    term = _ADDON.getSetting("filter_term").strip()
    return term.lower() if term else ""


def _show_kodi_paths():
    """Show main Kodi paths and let the user copy one to clipboard."""
    paths = [
        ("Log", xbmcvfs.translatePath("special://logpath/")),
        ("Addons", xbmcvfs.translatePath("special://home/addons/")),
        ("Userdata", xbmcvfs.translatePath("special://userdata/")),
        ("Home", xbmcvfs.translatePath("special://home/")),
        ("Temp", xbmcvfs.translatePath("special://temp/")),
        ("Profile", xbmcvfs.translatePath("special://profile/")),
        ("Thumbnails", xbmcvfs.translatePath("special://thumbnails/")),
        ("Database", xbmcvfs.translatePath("special://database/")),
    ]
    labels = ["{0}: {1}".format(name, path) for name, path in paths]
    sel = xbmcgui.Dialog().select(_T(32290), labels)
    if sel < 0:
        return
    chosen_path = paths[sel][1]
    if _copy_to_clipboard(chosen_path):
        xbmcgui.Dialog().notification(
            _ADDON_NAME, _T(32185), xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().ok(_ADDON_NAME, chosen_path)


def _classify_severity(line):
    """Classify a log line as 'error', 'warning', 'debug' or 'info'."""
    ll = ' ' + line.lower()
    for term in _SEVERITY_ERROR_TERMS:
        if term in ll:
            return 'error'
    for term in _SEVERITY_WARNING_TERMS:
        if term in ll:
            return 'warning'
    for term in _SEVERITY_DEBUG_TERMS:
        if term in ll:
            return 'debug'
    return 'info'


def _extract_timestamp(line):
    """Extract (HH:MM:SS, body) from a Kodi log line. Returns ('', line) if
    no timestamp is found.
    """
    if len(line) > 23 and line[4] == '-' and line[10] == ' ':
        ts = line[11:19]
        body = line[23:].strip()
        if body.startswith("T:"):
            space_idx = body.find(' ')
            if space_idx > 0:
                body = body[space_idx:].strip()
        for tag in _KODI_LOG_TAGS:
            if body.lower().startswith(tag):
                body = body[len(tag):].strip()
                break
        return ts, body
    return "", line


def _line_counts():
    return [_T(32103), _T(32104), _T(32105)], [50, 100, 200]


# ---------------------------------------------------------------------------
# Text views
# ---------------------------------------------------------------------------

def _view_filtered_log():
    """Show recent log entries filtered by the configured filter term."""
    lines = _read_log_lines()
    if not lines:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32100))
        return
    term = _get_filter_term()
    tail = lines[-100:]
    if term:
        filtered = [_sanitize_log_line(l.rstrip()) for l in tail if term in l.lower()]
        if not filtered:
            xbmcgui.Dialog().ok(_ADDON_NAME, _T(32107).format(term))
            return
    else:
        filtered = [_sanitize_log_line(l.rstrip()) for l in tail[-30:]]
    if _is_reverse_enabled():
        filtered.reverse()
    text = "\n".join(filtered[-50:])
    title = _T(32010).format(term) if term else _T(32011)
    xbmcgui.Dialog().textviewer(title, text)


def _view_full_log():
    """Show the full Kodi log."""
    lines = _read_log_lines()
    if not lines:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32100))
        return
    text = "".join(_sanitize_log_line(l) for l in (reversed(lines) if _is_reverse_enabled() else lines))
    xbmcgui.Dialog().textviewer(_T(32013), text)


def _view_errors_only():
    """Show only error, warning, exception and traceback lines."""
    lines = _read_log_lines()
    if not lines:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32100))
        return
    error_lines = [
        _sanitize_log_line(l.rstrip()) for l in lines[-500:]
        if _classify_severity(l) in ('error', 'warning')
    ]
    if not error_lines:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32101))
        return
    if _is_reverse_enabled():
        error_lines.reverse()
    text = "\n".join(error_lines[-80:])
    xbmcgui.Dialog().textviewer(_T(32014), text)


def _search_log():
    """Free-text search across the full Kodi log."""
    kb = xbmc.Keyboard('', _T(32106))
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        return
    raw_term = kb.getText().strip()
    term = raw_term.lower()
    lines = _read_log_lines()
    if not lines:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32100))
        return
    matches = [_sanitize_log_line(l.rstrip()) for l in lines if term in l.lower()]
    if not matches:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32107).format(raw_term))
        return
    if _is_reverse_enabled():
        matches.reverse()
    header = _T(32108).format(len(matches), raw_term)
    xbmcgui.Dialog().textviewer(header, "\n".join(matches[-80:]))


def _view_old_log():
    """Show the previous Kodi log (kodi.old.log)."""
    path = _get_old_log_path()
    lines = _read_file_lines(path)
    if not lines:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32150))
        return
    opts, counts = _line_counts()
    sel = xbmcgui.Dialog().select(_T(32102), opts)
    if sel < 0:
        return
    tail = lines[-counts[sel]:]
    if _is_reverse_enabled():
        tail = list(reversed(tail))
    text = "".join(_sanitize_log_line(l) for l in tail)
    xbmcgui.Dialog().textviewer(_T(32151), text)


# ---------------------------------------------------------------------------
# Visual viewer
# ---------------------------------------------------------------------------

def _format_visual_item(line):
    """Turn a log line into a severity-colored ListItem."""
    sanitized = _sanitize_log_line(line.rstrip())
    sev = _classify_severity(sanitized)
    ts, body = _extract_timestamp(sanitized)

    label_text = (body[:117] + "...") if len(body) > 120 else body

    if sev == 'error':
        label = "[COLOR red][B]X[/B][/COLOR] "
        if ts:
            label += "[COLOR grey]{0}[/COLOR] ".format(ts)
        label += "[COLOR red]{0}[/COLOR]".format(label_text)
        icon = 'DefaultIconError.png'
    elif sev == 'warning':
        label = "[COLOR yellow][B]![/B][/COLOR] "
        if ts:
            label += "[COLOR grey]{0}[/COLOR] ".format(ts)
        label += "[COLOR yellow]{0}[/COLOR]".format(label_text)
        icon = 'DefaultIconWarning.png'
    elif sev == 'debug':
        label = "[COLOR grey]- "
        if ts:
            label += "{0} ".format(ts)
        label += "{0}[/COLOR]".format(label_text)
        icon = 'DefaultIconInfo.png'
    else:
        label = "[COLOR white]-[/COLOR] "
        if ts:
            label += "[COLOR grey]{0}[/COLOR] ".format(ts)
        label += "{0}".format(label_text)
        icon = 'DefaultIconInfo.png'

    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': icon})
    li.setInfo('video', {'plot': sanitized})
    return li, sanitized


def _view_visual_log():
    """Visual log viewer: each line as a severity-colored list item."""
    log_path = _get_log_path()
    if not os.path.exists(log_path):
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32100))
        return

    filter_term = _get_filter_term()
    opts = [_T(32103), _T(32104), _T(32105)]
    if filter_term:
        opts.append(_T(32110).format(filter_term))
    opts.append(_T(32111))
    sel = xbmcgui.Dialog().select(_T(32109), opts)
    if sel < 0:
        return

    try:
        with open(log_path, 'r', encoding='utf-8', errors='replace') as fh:
            all_lines = fh.readlines()
    except OSError as exc:
        xbmcgui.Dialog().ok(_T(32222), str(exc))
        return

    if sel == 0:
        lines = all_lines[-50:]
    elif sel == 1:
        lines = all_lines[-100:]
    elif sel == 2:
        lines = all_lines[-200:]
    elif filter_term and sel == 3:
        lines = [l for l in all_lines if filter_term in l.lower()][-100:]
    else:
        lines = [l for l in all_lines if _classify_severity(l) == 'error'][-100:]

    if not lines:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32112))
        return

    if _is_reverse_enabled():
        lines.reverse()
    h = int(sys.argv[1])
    for raw in lines:
        li, sanitized = _format_visual_item(raw)
        encoded = base64.b64encode(sanitized.encode('utf-8')).decode('ascii')
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="show_line_detail", data=encoded),
            listitem=li,
            isFolder=False,
        )
    xbmcplugin.endOfDirectory(h)


def _show_line_detail(data):
    """Show a single log line in a full text viewer."""
    try:
        line = base64.b64decode(data).decode('utf-8')
        xbmcgui.Dialog().textviewer(_T(32113), line)
    except Exception:
        xbmcgui.Dialog().ok(_T(32222), _T(32114))


# ---------------------------------------------------------------------------
# Actions
# ---------------------------------------------------------------------------

def _log_info():
    """Show technical info about current and old Kodi log files."""
    log_path = _get_log_path()
    msg = "[B]{0}[/B]\n".format(_T(32120))
    if os.path.exists(log_path):
        size = os.path.getsize(log_path)
        try:
            with open(log_path, 'r', encoding='utf-8', errors='replace') as fh:
                total_lines = sum(1 for _ in fh)
        except OSError:
            total_lines = 0
        if size > 1048576:
            msg += _T(32121).format(size / 1048576.0) + "\n"
        else:
            msg += _T(32122).format(size / 1024.0) + "\n"
        msg += _T(32123).format(total_lines) + "\n"
        msg += _T(32124).format(log_path) + "\n"
    else:
        msg += _T(32125) + "\n"

    old_path = _get_old_log_path()
    if os.path.exists(old_path):
        osize = os.path.getsize(old_path)
        msg += "\n[B]kodi.old.log[/B]\n"
        if osize > 1048576:
            msg += _T(32121).format(osize / 1048576.0) + "\n"
        else:
            msg += _T(32122).format(osize / 1024.0) + "\n"

    xbmcgui.Dialog().textviewer(_T(32128), msg)


def _export_log():
    """Export the log to a TXT file with type and destination selection."""
    lines = _read_log_lines()
    if not lines:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32100))
        return

    filter_term = _get_filter_term()
    filter_label = filter_term if filter_term else "addon"
    opts = [
        _T(32130).format(filter_label),
        _T(32131),
        _T(32132),
    ]
    sel = xbmcgui.Dialog().select(_T(32133), opts)
    if sel < 0:
        return

    if sel == 0:
        if filter_term:
            filtered = [_sanitize_log_line(l) for l in lines if filter_term in l.lower()]
        else:
            filtered = [_sanitize_log_line(l) for l in lines[-200:]]
        suffix = filter_term if filter_term else "filtered"
    elif sel == 1:
        filtered = [_sanitize_log_line(l) for l in lines]
        suffix = "full"
    else:
        filtered = [
            _sanitize_log_line(l) for l in lines
            if _classify_severity(l) in ('error', 'warning')
        ]
        suffix = "errors"

    if not filtered:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32134))
        return

    dest_dir = xbmcgui.Dialog().browse(3, _T(32135), 'files')
    if not dest_dir:
        return

    ts = time.strftime("%Y%m%d_%H%M%S")
    fname = "kodi_log_{0}_{1}.txt".format(suffix, ts)
    if os.path.isdir(dest_dir):
        dest = os.path.join(dest_dir, fname)
    else:
        dest = dest_dir if dest_dir.lower().endswith('.txt') else dest_dir + '.txt'

    try:
        with open(dest, 'w', encoding='utf-8') as fh:
            fh.write(_T(32136).format(_ADDON_NAME, time.strftime('%d/%m/%Y %H:%M:%S')) + "\n")
            fh.write(_T(32137).format(opts[sel]) + "\n")
            fh.write(_T(32138).format(len(filtered)) + "\n")
            fh.write("=" * 60 + "\n\n")
            fh.writelines(filtered)
        xbmcgui.Dialog().ok(_T(32139), _T(32140).format(dest, len(filtered)))
    except OSError as exc:
        xbmcgui.Dialog().ok(_T(32222), _T(32141).format(exc))


def _toggle_debug():
    """Toggle Kodi debug logging on or off."""
    current = xbmc.getCondVisibility("System.GetBool(debug.showloginfo)")
    new_state = not current
    xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
        "params": {"setting": "debug.showloginfo", "value": new_state},
    }))
    if new_state:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32155))
    else:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32156))
    xbmc.executebuiltin("Container.Refresh")


def _toggle_reverse():
    """Toggle between newest-first and oldest-first log order."""
    current = _is_reverse_enabled()
    _ADDON.setSetting("reverse_log", "false" if current else "true")
    xbmc.executebuiltin("Container.Refresh")


def _log_stats():
    """Show log statistics: severity counts and most mentioned addons."""
    lines = _read_log_lines()
    if not lines:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32100))
        return

    errors = warnings = debugs = infos = 0
    addon_counter = Counter()

    for line in lines:
        sev = _classify_severity(line)
        if sev == 'error':
            errors += 1
        elif sev == 'warning':
            warnings += 1
        elif sev == 'debug':
            debugs += 1
        else:
            infos += 1
        for match in _ADDON_NAME_RE.findall(line):
            if '.' in match:
                addon_counter[match] += 1

    msg = "[B]{0}[/B]\n\n".format(_T(32160))
    msg += _T(32161).format(len(lines)) + "\n"
    msg += "[COLOR red]" + _T(32162).format(errors) + "[/COLOR]\n"
    msg += "[COLOR yellow]" + _T(32163).format(warnings) + "[/COLOR]\n"
    msg += "[COLOR grey]" + _T(32164).format(debugs) + "[/COLOR]\n"
    msg += _T(32165).format(infos) + "\n"

    top = addon_counter.most_common(10)
    if top:
        msg += "\n[B]{0}[/B]\n".format(_T(32166))
        for name, count in top:
            msg += "  {0}: {1:,}\n".format(name, count)

    xbmcgui.Dialog().textviewer(_T(32160), msg)


def _compare_logs():
    """Compare errors between the current and the old log."""
    log_path = _get_log_path()
    old_path = _get_old_log_path()
    if not os.path.exists(log_path) or not os.path.exists(old_path):
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32170))
        return

    current_lines = _read_file_lines(log_path)
    old_lines = _read_file_lines(old_path)

    current_errors = set()
    for line in current_lines:
        if _classify_severity(line) == 'error':
            _, body = _extract_timestamp(line)
            current_errors.add(body.strip())

    old_errors = set()
    for line in old_lines:
        if _classify_severity(line) == 'error':
            _, body = _extract_timestamp(line)
            old_errors.add(body.strip())

    new_errors = current_errors - old_errors

    msg = "[B]{0}[/B]\n\n".format(_T(32172))
    if new_errors:
        for err in sorted(new_errors)[:50]:
            sanitized = _sanitize_log_line(err)
            truncated = (sanitized[:120] + "...") if len(sanitized) > 120 else sanitized
            msg += "[COLOR red]- {0}[/COLOR]\n".format(truncated)
    else:
        msg += _T(32173)

    xbmcgui.Dialog().textviewer(_T(32171), msg)


def _system_info():
    """Show Kodi system information."""
    info = xbmc.getInfoLabel
    msg = "[B]Kodi[/B]\n"
    msg += "Build: {0}\n".format(info("System.BuildVersion"))
    msg += "OS: {0}\n".format(info("System.OSVersionInfo"))
    msg += "Kernel: {0}\n".format(info("System.KernelVersion"))
    msg += "\n[B]{0}[/B]\n".format(_T(32220))
    msg += "CPU: {0}\n".format(info("System.CpuUsage"))
    msg += "RAM: {0} / {1}\n".format(info("System.FreeMemory"), info("System.TotalMemory"))
    msg += "Screen: {0}\n".format(info("System.ScreenResolution"))
    msg += "\n[B]Python[/B]\n"
    msg += "Version: {0}\n".format(sys.version.split()[0])
    msg += "\n[B]Addons[/B]\n"
    addons_path = xbmcvfs.translatePath("special://home/addons/")
    if os.path.isdir(addons_path):
        addon_dirs = [d for d in os.listdir(addons_path)
                      if os.path.isdir(os.path.join(addons_path, d)) and not d.startswith('.')]
        msg += _T(32221).format(len(addon_dirs)) + "\n"
    msg += "\n[B]Log[/B]\n"
    debug_on = xbmc.getCondVisibility("System.GetBool(debug.showloginfo)")
    msg += "Debug: {0}\n".format("ON" if debug_on else "OFF")
    msg += "Path: {0}\n".format(_get_log_path())
    xbmcgui.Dialog().textviewer(_T(32180), msg)


def _copy_log_path():
    """Copy the log file path to the system clipboard."""
    path = _get_log_path()
    if _copy_to_clipboard(path):
        xbmcgui.Dialog().notification(_ADDON_NAME, _T(32185), xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32186) + "\n\n" + path)


def _pick_addon_filter():
    """Let the user pick an installed addon and show its log entries."""
    addons_path = xbmcvfs.translatePath("special://home/addons/")
    if not os.path.isdir(addons_path):
        return
    addon_dirs = sorted([
        d for d in os.listdir(addons_path)
        if os.path.isdir(os.path.join(addons_path, d)) and not d.startswith('.')
    ])
    if not addon_dirs:
        return
    sel = xbmcgui.Dialog().select(_T(32190), addon_dirs)
    if sel < 0:
        return
    chosen = addon_dirs[sel]
    _ADDON.setSetting("filter_term", chosen)
    lines = _read_log_lines()
    if not lines:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32100))
        return
    term = chosen.lower()
    filtered = [_sanitize_log_line(l.rstrip()) for l in lines if term in l.lower()]
    if not filtered:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32107).format(chosen))
        return
    if _is_reverse_enabled():
        filtered.reverse()
    xbmcgui.Dialog().textviewer(
        _T(32108).format(len(filtered), chosen),
        "\n".join(filtered[-200:]),
    )


def _delete_kodi_logs():
    """Delete kodi.log and/or kodi.old.log after user confirmation."""
    log_path = _get_log_path()
    old_path = _get_old_log_path()

    targets = []
    labels = []
    if os.path.exists(log_path):
        targets.append(log_path)
        labels.append("kodi.log")
    if os.path.exists(old_path):
        targets.append(old_path)
        labels.append("kodi.old.log")

    if not targets:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32100))
        return

    sel = xbmcgui.Dialog().multiselect(_T(32195), labels)
    if sel is None or not sel:
        return

    deleted = []
    errors = []
    for idx in sel:
        try:
            os.remove(targets[idx])
            deleted.append(labels[idx])
        except OSError as exc:
            errors.append("{0}: {1}".format(labels[idx], exc))

    if deleted:
        xbmcgui.Dialog().notification(
            _ADDON_NAME, _T(32198), xbmcgui.NOTIFICATION_INFO,
        )
    if errors:
        xbmcgui.Dialog().ok(_T(32222), _T(32199).format("\n".join(errors)))
    xbmc.executebuiltin("Container.Refresh")


def _check_log_size_warning():
    """Show a warning notification if kodi.log exceeds 10 MB."""
    log_path = _get_log_path()
    if not os.path.exists(log_path):
        return
    try:
        size = os.path.getsize(log_path)
    except OSError:
        return
    if size > 10485760:
        xbmcgui.Dialog().notification(
            _ADDON_NAME,
            _T(32230).format(size / 1048576.0).split('\n')[0],
            xbmcgui.NOTIFICATION_WARNING, 5000,
        )


def _search_log_regex():
    """Search the full Kodi log using a regex pattern."""
    kb = xbmc.Keyboard('', _T(32236))
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        return
    raw_pattern = kb.getText().strip()
    try:
        compiled = re.compile(raw_pattern, re.IGNORECASE)
    except re.error as exc:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32237).format(exc))
        return
    lines = _read_log_lines()
    if not lines:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32100))
        return
    matches = [_sanitize_log_line(l.rstrip()) for l in lines if compiled.search(l)]
    if not matches:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32107).format(raw_pattern))
        return
    if _is_reverse_enabled():
        matches.reverse()
    header = _T(32108).format(len(matches), raw_pattern)
    xbmcgui.Dialog().textviewer(header, "\n".join(matches[-80:]))


def _export_json():
    """Export the log as a structured JSON file."""
    lines = _read_log_lines()
    if not lines:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32100))
        return
    entries = []
    for line in lines:
        sanitized = _sanitize_log_line(line.rstrip())
        sev = _classify_severity(sanitized)
        ts, body = _extract_timestamp(sanitized)
        entries.append({
            "timestamp": ts,
            "severity": sev,
            "message": body,
        })
    dest_dir = xbmcgui.Dialog().browse(3, _T(32241), 'files')
    if not dest_dir:
        return
    ts_file = time.strftime("%Y%m%d_%H%M%S")
    fname = "kodi_log_{0}.json".format(ts_file)
    if os.path.isdir(dest_dir):
        dest = os.path.join(dest_dir, fname)
    else:
        dest = dest_dir if dest_dir.lower().endswith('.json') else dest_dir + '.json'
    try:
        with open(dest, 'w', encoding='utf-8') as fh:
            json.dump({
                "exported_by": _ADDON_NAME,
                "date": time.strftime('%Y-%m-%dT%H:%M:%S'),
                "total_entries": len(entries),
                "entries": entries,
            }, fh, ensure_ascii=False, indent=2)
        xbmcgui.Dialog().ok(_T(32242), _T(32243).format(dest, len(entries)))
    except OSError as exc:
        xbmcgui.Dialog().ok(_T(32222), _T(32141).format(exc))


def _view_event_log():
    """Show recent Kodi event log entries."""
    lines = _read_log_lines()
    if not lines:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32100))
        return
    event_terms = ('notification', 'event', 'signal', 'callback')
    events = []
    for line in lines[-500:]:
        ll = line.lower()
        if any(t in ll for t in event_terms):
            sanitized = _sanitize_log_line(line.rstrip())
            ts, body = _extract_timestamp(sanitized)
            label = ""
            if ts:
                label = "[COLOR grey]{0}[/COLOR] ".format(ts)
            sev = _classify_severity(sanitized)
            if sev == 'error':
                label += "[COLOR red]{0}[/COLOR]".format(body[:120])
            elif sev == 'warning':
                label += "[COLOR yellow]{0}[/COLOR]".format(body[:120])
            else:
                label += body[:120]
            events.append(label)
    if not events:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32252))
        return
    if _is_reverse_enabled():
        events.reverse()
    text = "\n".join(events[-80:])
    xbmcgui.Dialog().textviewer(_T(32250), text)


def _show_api_info():
    """Show available RunScript commands for other addons."""
    msg = "[B]RunScript API[/B]\n\n"
    msg += "xbmc.executebuiltin(\n"
    msg += '  "RunScript(plugin.program.loiolog, show_log)"\n'
    msg += ")\n\n"
    msg += "[B]Commands:[/B]\n"
    msg += "  show_log — Open log viewer\n"
    msg += "  show_errors — Show errors only\n"
    msg += "  show_stats — Show log statistics\n"
    msg += "  show_info — Show system info\n"
    msg += "  toggle_debug — Toggle debug logging\n"
    xbmcgui.Dialog().textviewer(_T(32260), msg)


def _upload_log():
    """Upload kodi.log or kodi.old.log to a paste service and show the URL."""
    opts = [_T(32276), _T(32277)]
    sel = xbmcgui.Dialog().select(_T(32275), opts)
    if sel < 0:
        return
    path = _get_log_path() if sel == 0 else _get_old_log_path()
    lines = _read_file_lines(path)
    if not lines:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32100))
        return
    if len(lines) > 15000:
        lines = lines[-15000:]
    content = "".join(_sanitize_log_line(l) for l in lines)
    xbmcgui.Dialog().notification(_ADDON_NAME, _T(32271), xbmcgui.NOTIFICATION_INFO, 2000)
    sock = None
    try:
        import socket
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(30)
        sock.connect(("termbin.com", 9999))
        sock.sendall(content.encode('utf-8'))
        sock.shutdown(socket.SHUT_WR)
        url = sock.recv(1024).decode('utf-8').strip()
    except Exception as exc:
        xbmcgui.Dialog().ok(_T(32222), _T(32273).format(exc))
        return
    finally:
        if sock:
            try:
                sock.close()
            except Exception:
                pass
    _copy_to_clipboard(url)
    xbmcgui.Dialog().ok(_T(32278), _T(32272).format(url))


def _serve_log_on_network():
    """Serve the log over the local network for viewing from another device."""
    lines = _read_log_lines()
    if not lines:
        xbmcgui.Dialog().ok(_ADDON_NAME, _T(32100))
        return

    content = "".join(_sanitize_log_line(l) for l in lines)
    escaped = content.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    html = (
        '<!DOCTYPE html><html><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        '<title>Kodi Log</title>'
        '<style>'
        'body{background:#1a1a2e;color:#e0e0e0;font-family:monospace;'
        'font-size:13px;padding:12px;margin:0}'
        'h1{color:#e94560;font-size:18px;margin:0 0 12px}'
        'pre{white-space:pre-wrap;word-wrap:break-word;line-height:1.5}'
        '</style></head><body>'
        '<h1>Kodi Log &mdash; LoioLog</h1>'
        '<pre>%s</pre></body></html>'
    ) % escaped
    html_bytes = html.encode('utf-8')

    import socket
    import threading
    from http.server import HTTPServer, BaseHTTPRequestHandler

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(2)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
    except Exception:
        local_ip = "127.0.0.1"

    class _Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(html_bytes)))
            self.end_headers()
            self.wfile.write(html_bytes)

        def log_message(self, fmt, *args):
            pass

    port = 8989
    try:
        server = HTTPServer(("0.0.0.0", port), _Handler)
    except OSError:
        xbmcgui.Dialog().ok(_T(32222), _T(32313).format(port))
        return

    thread = threading.Thread(target=server.serve_forever)
    thread.daemon = True
    thread.start()

    url = "http://{0}:{1}".format(local_ip, port)
    _copy_to_clipboard(url)
    xbmcgui.Dialog().ok(_T(32310), _T(32311).format(url))
    server.shutdown()

# ---------------------------------------------------------------------------
# Main menu
# ---------------------------------------------------------------------------

def _add_menu_item(h, label, action, icon='DefaultIconInfo.png', plot="", is_folder=False, color=None):
    if color:
        display = "[COLOR {0}]{1}[/COLOR]".format(color, label)
    else:
        display = label
    li = xbmcgui.ListItem(label=display)
    li.setArt({'icon': icon})
    if plot:
        li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action), listitem=li, isFolder=is_folder)


def _add_separator(h, label):
    display = "[COLOR gold][B]── {0} ──[/B][/COLOR]".format(label)
    li = xbmcgui.ListItem(label=display)
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)


def _main_menu():
    h = int(sys.argv[1])
    filter_term = _get_filter_term()

    _check_log_size_warning()

    _add_separator(h, _T(32300))

    if filter_term:
        fl = _T(32010).format(filter_term)
    else:
        fl = _T(32011)
    plot = _T(32200)
    if filter_term:
        plot += _T(32201).format(filter_term)
    if _is_sanitize_enabled():
        plot += "\n" + _T(32202)
    _add_menu_item(h, fl, "view_filtered_log", plot=plot)

    _add_menu_item(h, _T(32013), "view_full_log", plot=_T(32204))

    _add_menu_item(h, _T(32014), "view_errors_only",
                   icon='DefaultIconError.png', plot=_T(32205))

    _add_menu_item(h, _T(32012), "view_visual_log",
                   icon='DefaultPicture.png', plot=_T(32203), is_folder=True)

    _add_menu_item(h, _T(32020), "view_old_log", plot=_T(32211))

    _add_menu_item(h, _T(32250), "view_event_log", plot=_T(32251))

    _add_separator(h, _T(32301))

    _add_menu_item(h, _T(32016), "search_log", plot=_T(32207))

    _add_menu_item(h, _T(32235), "search_log_regex", plot=_T(32238))

    _add_separator(h, _T(32302))

    _add_menu_item(h, _T(32022), "log_stats", plot=_T(32213))

    _add_menu_item(h, _T(32023), "compare_logs", plot=_T(32214))

    _add_menu_item(h, _T(32018), "log_info", plot=_T(32209))

    _add_separator(h, _T(32303))

    _add_menu_item(h, _T(32017), "export_log",
                   icon='DefaultAddonService.png', plot=_T(32208))

    _add_menu_item(h, _T(32240), "export_json",
                   icon='DefaultAddonService.png', plot=_T(32244))

    _add_menu_item(h, _T(32270), "upload_log",
                   icon='DefaultAddonService.png', plot=_T(32274))

    _add_menu_item(h, _T(32310), "serve_log_network",
                   icon='DefaultAddonService.png', plot=_T(32312))

    _add_separator(h, _T(32304))

    _add_menu_item(h, _T(32024), "system_info", plot=_T(32215))

    debug_on = xbmc.getCondVisibility("System.GetBool(debug.showloginfo)")
    debug_label = _T(32157) if debug_on else _T(32158)
    _add_menu_item(h, debug_label, "toggle_debug", plot=_T(32212))

    reverse_label = _T(32315) if _is_reverse_enabled() else _T(32314)
    _add_menu_item(h, reverse_label, "toggle_reverse", plot=_T(32316))

    _add_menu_item(h, _T(32025), "copy_log_path", plot=_T(32216))

    _add_menu_item(h, _T(32026), "pick_addon_filter", plot=_T(32217))

    _add_menu_item(h, _T(32290), "show_kodi_paths", plot=_T(32291))

    _add_menu_item(h, _T(32260), "show_api_info", plot=_T(32261))

    _add_separator(h, _T(32305))

    _add_menu_item(h, _T(32027), "delete_kodi_logs",
                   icon='DefaultIconError.png', color="red", plot=_T(32218))

    xbmcplugin.endOfDirectory(h)


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

def _router():
    params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip('?')))
    action = params.get("action", "")

    if not action:
        _main_menu()
    elif action == "view_filtered_log":
        _view_filtered_log()
    elif action == "view_full_log":
        _view_full_log()
    elif action == "view_errors_only":
        _view_errors_only()
    elif action == "view_visual_log":
        _view_visual_log()
    elif action == "show_line_detail":
        _show_line_detail(params.get("data", ""))
    elif action == "view_old_log":
        _view_old_log()
    elif action == "view_event_log":
        _view_event_log()
    elif action == "search_log":
        _search_log()
    elif action == "search_log_regex":
        _search_log_regex()
    elif action == "log_stats":
        _log_stats()
    elif action == "compare_logs":
        _compare_logs()
    elif action == "log_info":
        _log_info()
    elif action == "export_log":
        _export_log()
    elif action == "export_json":
        _export_json()
    elif action == "upload_log":
        _upload_log()
    elif action == "serve_log_network":
        _serve_log_on_network()
    elif action == "system_info":
        _system_info()
    elif action == "toggle_debug":
        _toggle_debug()
    elif action == "toggle_reverse":
        _toggle_reverse()
    elif action == "copy_log_path":
        _copy_log_path()
    elif action == "pick_addon_filter":
        _pick_addon_filter()
    elif action == "show_kodi_paths":
        _show_kodi_paths()
    elif action == "show_api_info":
        _show_api_info()
    elif action == "delete_kodi_logs":
        _delete_kodi_logs()


def _handle_runscript():
    """Handle RunScript commands from other addons."""
    if len(sys.argv) < 2:
        return False
    cmd = sys.argv[1].strip().lower() if not sys.argv[1].isdigit() else ""
    if not cmd:
        return False
    if cmd == "show_log":
        _view_filtered_log()
    elif cmd == "show_errors":
        _view_errors_only()
    elif cmd == "show_stats":
        _log_stats()
    elif cmd == "show_info":
        _system_info()
    elif cmd == "toggle_debug":
        _toggle_debug()
    else:
        return False
    return True


if __name__ == "__main__":
    if not _handle_runscript():
        _router()
